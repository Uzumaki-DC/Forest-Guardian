const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const context={window:{}};vm.createContext(context);
for(const file of ['story.js','dialogue-pages.js'])vm.runInContext(fs.readFileSync(__dirname+'/dist/'+file,'utf8'),context);
const {ForestDialogue,FOREST_STORY}=context.window;
let checked=0;
for(const node of Object.values(FOREST_STORY.nodes)){
  for(const line of [node.text,...(node.variants||[]).map(v=>v.text)])for(const width of [1,30,120,230]){
    const pages=ForestDialogue.paginate(line,t=>t.length<=width);
    assert.equal(pages.join(''),line,'Pagination must preserve every character');
    assert(pages.every(p=>p.length<=width),'Every page fits the supplied measure');checked++;
  }
}
for(const text of ['','A'.repeat(2500),'🍃'.repeat(130),'A long word: '+('Z'.repeat(1200))]){
  const pages=ForestDialogue.paginate(text,t=>Array.from(t).length<=50);
  assert.equal(pages.join(''),text);assert(pages.every(p=>Array.from(p).length<=50));
}
assert.equal(FOREST_STORY.characters.you.talkingPose,'talking');
assert.equal(FOREST_STORY.characters.you.defaultPose,'thinking');
assert.equal(FOREST_STORY.characters.you.bubble,'hero');
assert.equal(FOREST_STORY.characters.careless.bubble,'villain');
for(const who of ['you','careless'])for(const pose of Object.values(FOREST_STORY.characters[who].poses)){
  assert(fs.existsSync(__dirname+'/dist/'+pose.src),'Portrait asset exists');
  assert(pose.viewBox.length===4&&pose.viewBox[2]>0&&pose.viewBox[3]>0);
}
console.log(`Passed: ${checked} dialogue pagination cases, long words, Unicode, asset references, and pose defaults.`);
