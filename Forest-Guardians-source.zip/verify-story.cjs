// Run: node verify-story.cjs. No browser or packages required.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const context={window:{}};vm.createContext(context);
for(const file of ['story.js','model.js'])vm.runInContext(fs.readFileSync(__dirname+'/dist/'+file,'utf8'),context);
const story=context.window.FOREST_STORY,model=context.window.ForestModel,endings=new Set();
let paths=0,ignited=0,dampBranches=0;
function walk(id,state,depth,decisions){
  assert(depth<40,'Every path must terminate');
  if(id==='ending'){
    paths++;endings.add(model.ending(state));assert.equal(decisions,5);
    assert(model.score(state,story)>=0&&model.score(state,story)<=story.baseline);
    if(state.burned||state.drained||state.fire)assert(model.score(state,story)<story.baseline,'Damage is never fully reversed');
    if(state.ignored){if(state.burned||state.drained){assert(state.fire);ignited++;}else{assert(!state.fire);dampBranches++;}}
    return;
  }
  const node=story.nodes[id];assert(node,'Missing node: '+id);assert(story.characters[node.speaker]);
  if(node.recovery)state={...state,recovery:1};
  if(node.choices)for(const choice of node.choices){assert(choice.label&&choice.say&&choice.journal);walk(choice.next,model.choose(state,choice),depth+1,decisions+1);}
  else walk(node.next,state,depth+1,decisions);
}
walk('arrival',model.initial(),0,0);
assert.equal(paths,32);assert.equal(endings.size,3);assert(ignited>0&&dampBranches>0);
const damaged={...model.initial(),burned:true,drained:true,fire:true};
assert(model.score({...damaged,recovery:.5},story)>model.score(damaged,story));
assert(model.score({...damaged,recovery:.5},story)<model.score({...damaged,recovery:1},story));
console.log(`Passed: ${paths} story paths, ${endings.size} endings, conditional ignition, cumulative damage, gradual partial recovery.`);
