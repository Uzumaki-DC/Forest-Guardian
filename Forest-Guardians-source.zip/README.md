# Forest Guardians: The Forest Remembers

Suzanna's Codefest prototype is now a branching visual novel about SDG 15, with one connected Southeast Asian forest and a volunteer from Singapore.

## Play

Serve dist/ with any static web server, or open dist/index.html. There is no build step or dependency installation. Enter a player name, read character dialogue, and make five decisions through five chapters. There are 32 paths and three endings. The notebook records the current journey; progress and reflections last for the page visit.

Original synthesized voice-like sounds follow the letter-by-letter dialogue. Audio begins only after a user gesture. Mute and text speed preferences persist in this browser. Instant text and reduced-motion preferences skip typing animation. No Nintendo audio or assets are used.

## Edit

- dist/story.js contains characters, editable dialogue, branch variants, choices, graph links, invented damage values, and recovery duration.
- dist/model.js contains the pure rules for cumulative damage, conditional ignition, partial recovery, and ending selection.
- dist/novel.js contains dialogue, sound, creator controls, portraits, journal, and state handling.
- dist/forest-art.js contains the original animated SVG forest. styles.css provides the base theme; novel.css provides the visual novel layout.

Use Suzanna's studio in the footer to edit any dialogue line or branch variant and the recovery duration. Save each edited line before selecting another. Export the saved script as story.js to replace dist/story.js and republish. Creator edits stay in browser storage, separate from the earlier simulation's settings. Current dialogue stays unchanged; edits appear the next time that line plays. Synthesized sound is a narration placeholder; recorded media may be added later.

## Story and educational model

The five decisions concern listening to a character, slash-and-burn clearing, peatland drainage, a smouldering cigarette, and the restoration response. Choices persist across chapters. In this deliberately simplified story, ignoring an ember causes fire only if earlier clearing or drainage has left drier fuel; damp vegetation does not ignite on the alternate branch. This is an illustrative condition, not a prediction or a guarantee of real fire behaviour. A cigarette does not always cause a fire. No real incident or smoking regulation is asserted.

Expert-led restoration unfolds over 12 seconds by default, representing much longer real timescales. It recovers 60% of the invented score loss, never fully repairing damage. Clearing and fire remove mature trees; seedlings do not replace them. Rewetting improves water conditions without replacing lost peat. Prevention, partial recovery, and unresolved risks lead to distinct endings. The habitat is a fictional regional composite, not a specific Singapore forest or scientific model.

Children do not handle smouldering cigarettes or fight fires. They alert Ranger Maya from safety; safe disposal and fire response are handled by appropriate adults or trained responders. The site links to NParks, UNEP, and the US Forest Service for background.

## Verification

The story graph has been checked across all 32 paths for valid transitions, five decisions per playthrough, all three endings, cumulative state, conditional ignition, and incomplete recovery. Browser checks cover dialogue reveal and skip, voice controls, persistent consequences, recovery gating, endings, responsive layout, restart, and creator editing.

## Player portrait

The player portrait is dist/assets/player-guardian.png, a transparent cutout based on Suzanna's supplied character reference. It appears in the speaking position for player dialogue and beside the current speaker while a decision is available. It hides when the next character speaks or the story restarts. The source image retains the white hair, floral horned mask, white costume, and sage-green accents.

Asset preparation used the built-in image generation editor. Prompt: Use case: background-extraction / identity-preserve. Edit target: the supplied image. Create a clean transparent PNG cutout of THIS EXACT illustrated chibi character for a visual-novel player portrait. Remove the entire forest background, keeping the whole character including hair, horned floral animal mask resting on left side of head, white ears/horns, sage-green leaf decorations, long off-white hair, grey-violet eyes, pale face, white outfit, sage green cuffs, sash and hanging belt tail, cross-body pouch, white trousers and white-grey boots. Preserve the same face, drawing style, colors, pose, proportions and costume details as closely as possible. Character alone, full body entirely visible, edges clean, a small transparent margin, no background or ground shadow, no text or new objects. Do not redesign the character. This is an extraction of the supplied character, not an alternative character.

## In-scene conversations

The forest stage now contains both actors, the supplied speech-box artwork, dialogue pagination, choice cards, and recovery feedback. The player remains on the left; the current conversation partner remains on the right during player replies. The speaker moves gently while text unfolds; instant text and reduced-motion settings skip that movement.

Hero pose 1 and Villain pose 1 are used directly from the supplied PNGs. Inline SVG view boxes remove transparent margins at render time without changing the artwork. The player's earlier portrait is the listening/thinking pose. Hero and villain speech boxes retain the supplied colours and decoration; Maya and Pip use the matching cream-and-gold style.

Character settings in dist/story.js now support bubble ('hero', 'villain', or 'neutral'), defaultPose, talkingPose, and poses. Each image pose declares src, viewBox [x,y,width,height], and original size [width,height]. Nodes can optionally set pose for the speaker, playerPose for the listening player, or partner to select the right-hand character. These metadata fields are included when exporting the story from the creator studio.

Dialogue is measured and paginated to fit the foreground box. Pages do not create extra transcript records or advance the story graph. Choices appear only after the final page. Recovery begins after its explanation is read and blocks progression until complete. Resizing preserves the reader's approximate position without duplicating the transcript. Full unpaginated lines remain in the dialogue history and creator editor.

Checks: node verify-story.cjs covers all 32 story paths. node verify-dialogue.cjs covers 96 pagination cases plus long words, Unicode, asset references, and pose defaults.
