# Forest Guardians: The Forest Remembers

Suzanna's Codefest prototype is now a branching visual novel about SDG 15, with one connected Southeast Asian forest and a volunteer from Singapore.

## Play

Serve dist/ with any static web server, or open dist/index.html. There is no build step or dependency installation. Enter a player name, read character dialogue, and make five decisions through five chapters. There are 32 paths and three endings. The notebook records the current journey; progress and reflections last for the page visit.

Original synthesized voice-like sounds follow the letter-by-letter dialogue. Audio begins only after a user gesture. Mute and text speed preferences persist in this browser. Instant text and reduced-motion preferences skip typing animation. No Nintendo audio or assets are used.

## Edit

- dist/story.js contains characters, editable dialogue, branch variants, choices, graph links, invented damage values, and recovery duration.
- dist/model.js contains the pure rules for cumulative damage, conditional ignition, partial recovery, and ending selection.
- dist/novel.js contains dialogue, sound, creator controls, portraits, journal, and state handling.
- dist/forest-art.js contains the original animated SVG forest. styles.css provides the base theme; novel.css provides the visual novel layout.

Use Suzanna's studio in the footer to edit any dialogue line or branch variant and the recovery duration. Save each edited line before selecting another. Export the saved script as story.js to replace dist/story.js and republish. Creator edits stay in browser storage, separate from the earlier simulation's settings. Current dialogue stays unchanged; edits appear the next time that line plays. Synthesized sound is a narration placeholder; recorded media may be added later.

## Story and educational model

The five decisions concern listening to a character, slash-and-burn clearing, peatland drainage, a smouldering cigarette, and the restoration response. Choices persist across chapters. In this deliberately simplified story, ignoring an ember causes fire only if earlier clearing or drainage has left drier fuel; damp vegetation does not ignite on the alternate branch. This is an illustrative condition, not a prediction or a guarantee of real fire behaviour. A cigarette does not always cause a fire. No real incident or smoking regulation is asserted.

Expert-led restoration unfolds over 12 seconds by default, representing much longer real timescales. It recovers 60% of the invented score loss, never fully repairing damage. Clearing and fire remove mature trees; seedlings do not replace them. Rewetting improves water conditions without replacing lost peat. Prevention, partial recovery, and unresolved risks lead to distinct endings. The habitat is a fictional regional composite, not a specific Singapore forest or scientific model.

Children do not handle smouldering cigarettes or fight fires. They alert Ranger Maya from safety; safe disposal and fire response are handled by appropriate adults or trained responders. The site links to NParks, UNEP, and the US Forest Service for background.

## Verification

The story graph has been checked across all 32 paths for valid transitions, five decisions per playthrough, all three endings, cumulative state, conditional ignition, and incomplete recovery. Browser checks cover dialogue reveal and skip, voice controls, persistent consequences, recovery gating, endings, responsive layout, restart, and creator editing.
